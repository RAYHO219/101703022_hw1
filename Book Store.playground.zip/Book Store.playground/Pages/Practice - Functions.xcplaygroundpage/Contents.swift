/*:

 # Your shopping cart

 Now, it's your turn to create your shopping list.
 
 Assume that you want to buy following books:

 * "Digital Fortress" by "Dan Brown", $9.99
 * "Angels & Demons" by "Dan Brown", $17.00
 * "The Da Vinci Code" by "Dan Brown", $9.99
 * "Deception Point" by "Dan Brown", $17.00
 * "Harry Potter and the Goblet of Fire" by "J.K. Rowling", $12.99
 * "Harry Potter and the Half-Blood Prince" by "J.K. Rowling", $12.99
 * "Harry Potter and the Deathly Hallows" by "J.K. Rowling", $14.99
 * "旅行與讀書" by "詹宏志", $12.00
 * "國宴與家宴" by "王宣一", $7.99

 Then, let's create a book store first:
 
 */
var mybook : [[String: String]] = [
    ["author": "Dan Brown", "title": "Digital Fortress",  "price": "9.99"],
    ["author": "Dan Brown", "title": "Angels & Demons",   "price": "17.00"],
    ["author": "Dan Brown", "title": "The Da Vinci Code", "price": "9.99"],
    ["author": "Dan Brown", "title": "Deception Poing",   "price": "17.00" ],
    ["author": "J.K. Rowling", "title": "Harry Potter and the Goblet of Fire", "price": "12.99"],
    ["author": "J.K. Rowling", "title": "Harry Potter and the Half-Blood Prince", "price": "12.99"],
    ["author": "J.K. Rowling", "title": "Harry Potter and the Deathly Hallows", "price": "14.99"],
    ["author": "詹宏志", "title": "旅行與讀書", "price": "12.00"],
    ["author": "王宣一", "title": "國宴與家宴", "price": "7.99"]
]

var bookStore = BookStore()

/*:
 
 Now start to feed data to the book store.
 
 You have to prepare following functions:
 1. A function which returns the name of authors in a set or a list. 
    _Note, you have to remove duplicated authors._
 2. A function which returns the totoal price of books to purchase
 3. A function which returns the number of books to buy
 4. A function which returns a book with its title, author, and price by a given index.
    If the index is out of bound, return `nil`.
 
 */

// Use this
func distinctAuthors() -> Set<String> {
var authors:Set<String>
 authors = [mybook[0]["author"]!,mybook[1]["author"]!,mybook[2]["author"]!,mybook[3]["author"]!,mybook[4]["author"]!,mybook[5]["author"]!,mybook[6]["author"]!,mybook[7]["author"]!,mybook[8]["author"]!]
    return authors
}
// or this
//func distinctAuthors() -> [String] { ... }
// then
bookStore.setDataSource(authorsGetter: distinctAuthors)

func totalBookPrice() -> Double {

var totalprice:Double
totalprice = Double(mybook[0]["price"]!)! + Double(mybook[1]["price"]!)! + Double(mybook[2]["price"]!)! + Double(mybook[3]["price"]!)! + Double(mybook[4]["price"]!)! + Double(mybook[5]["price"]!)! + Double(mybook[6]["price"]!)! + Double(mybook[7]["price"]!)! + Double(mybook[8]["price"]!)!
return totalprice
}
bookStore.setDataSource(priceCalculator: totalBookPrice)

//func getBook(at index: Int) -> (title: String, author: String, price: Double)? {
    
    
    
    
//return nil }
func getBook(at index: Int) -> (title: String, author: String, price: Double)?{
    if index >= mybook.count {return nil }
    var eachbook = mybook[index]
    let title = eachbook["title"]
    let author = eachbook["author"]
    let price = Double(eachbook["price"]!)
    return(title!, author!, price!)
}



bookStore.setDataSource(bookGetter: getBook(at:))

/*:

 Finally, let's show the book store shopping cart:

 */

bookStore.showInPlayground()

//: ---
//: [<- Previous](@previous) | [Next ->](@next)
